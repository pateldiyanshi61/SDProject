import React, { useState, useEffect } from 'react';
import { AlertCircle, DollarSign, Send, Bell, User, LogOut, Menu, X, TrendingUp, CreditCard, History, Eye, EyeOff, Users, Settings, Shield, Plus, Edit, Trash2,} from 'lucide-react';
import {ArrowDownCircle } from 'lucide-react';
import {ArrowUpCircle} from 'lucide-react';
import { Search } from 'lucide-react';
// API Configuration
const API_BASE_URL = 'http://localhost:9000';

// Fixed API Helper Functions
const api = {
  async request(endpoint, options = {}) {
    const token = localStorage.getItem('token');
    
    // Ensure we always have proper headers
    const headers = {
      'Content-Type': 'application/json',
      ...options.headers,
    };
    
    // Add Authorization header if token exists
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
      
      // Debug: Decode JWT to see what's inside
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        console.log('JWT Payload:', payload);
      } catch (e) {
        console.error('Failed to decode JWT:', e);
      }
    } else {
      console.warn('No token found in localStorage!');
    }

    console.log('Making request to:', `${API_BASE_URL}${endpoint}`);
    console.log('Headers:', JSON.stringify(headers, null, 2));
    console.log('Request body:', options.body);

    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers,
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ detail: 'An error occurred' }));
      console.error('API Error Response:', error);
      throw new Error(error.detail || 'Request failed');
    }

    return response.json();
  },

  auth: {
    register: (email, password, role = 'user') =>
      api.request('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify({ email, password, role }),
      }),
    login: (email, password) =>
      api.request('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      }),
    me: () => api.request('/api/auth/me'),
  },

  accounts: {
    list: (userId) => api.request(userId ? `/api/accounts?user_id=${userId}` : '/api/accounts'),
    create: (accountNumber, userId, balance = 0) =>
      api.request('/api/accounts', {
        method: 'POST',
        body: JSON.stringify({ accountNumber, userId, balance, currency: 'INR', status: 'active' }),
      }),
    delete: (accountId) => api.request(`/api/accounts/${accountId}`, { method: 'DELETE' }),
  },
transactions: {
    list: () => api.request('/api/transactions'),
    transfer: (fromAccount, toAccount, amount, currency = 'INR') => {
      console.log('Transfer request:', { fromAccount, toAccount, amount, currency });
      return api.request('/api/transactions/transfer', {
        method: 'POST',
        body: JSON.stringify({ fromAccount, toAccount, amount, currency }),
      });
    },
    // ADD THIS NEW METHOD:
    deposit: (accountNumber, amount, currency = 'INR', description = '') =>
      api.request('/api/transactions/deposit', {
        method: 'POST',
        body: JSON.stringify({ accountNumber, amount, currency, description }),
      }),
      withdraw: (accountNumber, amount, currency = 'INR', description = '') =>
      api.request('/api/transactions/withdraw', {
        method: 'POST',
        body: JSON.stringify({ accountNumber, amount, currency, description }),
      }),

  },

  notifications: {
    list: () => api.request('/api/notifications'),
    unreadCount: () => api.request('/api/notifications/unread-count'),
   
  },

  admin: {
    stats: () => api.request('/api/admin/stats'),
    freezeAccount: (accountNumber, freeze = true) =>
      api.request('/api/admin/freeze-account', {
        method: 'POST',
        body: JSON.stringify({ accountNumber, freeze }),
      }),
  },

  users: {
    list: () => api.request('/api/auth/users'),
    listUsersOnly: () => api.request('/api/users'),
  },
};

// Login Page Component
const LoginPage = ({ onLogin }) => {
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('user');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isRegister) {
        await api.auth.register(email, password, role);
        setIsRegister(false);
        setError('Registration successful! Please login.');
      } else {
        const data = await api.auth.login(email, password);
        localStorage.setItem('token', data.access_token);
        onLogin();
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated background circles */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-blue-400/20 to-purple-400/20 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-br from-pink-400/20 to-yellow-400/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
      
      <div className="max-w-md w-full relative z-10">
        <div className="bg-white/80 backdrop-blur-xl rounded-3xl shadow-2xl p-8 border border-white/20">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 rounded-2xl mb-4 shadow-lg transform hover:rotate-6 transition-transform">
              <DollarSign className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
              SecureBank
            </h1>
            <p className="text-gray-600 mt-2">Your trusted banking partner</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 bg-gray-50/50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                placeholder="you@example.com"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 bg-gray-50/50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                  placeholder="••••••••"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            {isRegister && (
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Role</label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  className="w-full px-4 py-3 bg-gray-50/50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                >
                  <option value="user">User</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
            )}

            {error && (
              <div className={`flex items-center gap-2 p-4 rounded-xl backdrop-blur-sm ${
                error.includes('successful') 
                  ? 'bg-green-50/80 border border-green-200' 
                  : 'bg-red-50/80 border border-red-200'
              }`}>
                <AlertCircle className={`w-5 h-5 ${
                  error.includes('successful') ? 'text-green-600' : 'text-red-600'
                }`} />
                <p className={`text-sm font-medium ${
                  error.includes('successful') ? 'text-green-800' : 'text-red-800'
                }`}>{error}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 text-white py-4 rounded-xl font-semibold shadow-lg hover:shadow-xl transform hover:scale-[1.02] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  Processing...
                </span>
              ) : (
                isRegister ? 'Create Account' : 'Sign In'
              )}
            </button>
          </form>

          <div className="mt-6 text-center">
            <button
              onClick={() => {
                setIsRegister(!isRegister);
                setError('');
              }}
              className="text-purple-600 hover:text-purple-700 text-sm font-semibold transition-colors"
            >
              {isRegister ? 'Already have an account? Sign in' : "Don't have an account? Create one"}
            </button>
          </div>
        </div>

        <p className="text-center text-gray-500 text-sm mt-8">
          🔒 Secure • Fast • Reliable
        </p>
      </div>
    </div>
  );
};

// User Dashboard Component
const UserDashboard = ({ user, onLogout }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [accounts, setAccounts] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const [fromAccount, setFromAccount] = useState('');
  const [toAccount, setToAccount] = useState('');
  const [amount, setAmount] = useState('');
  const [transferLoading, setTransferLoading] = useState(false);
  const [transferMessage, setTransferMessage] = useState('');

  const [depositAccount, setDepositAccount] = useState('');
  const [depositAmount, setDepositAmount] = useState('');
  const [depositDescription, setDepositDescription] = useState('');
  const [depositLoading, setDepositLoading] = useState(false);
  const [depositMessage, setDepositMessage] = useState('');

  const [withdrawAccount, setWithdrawAccount] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawDescription, setWithdrawDescription] = useState('');
  const [withdrawLoading, setWithdrawLoading] = useState(false);
  const [withdrawMessage, setWithdrawMessage] = useState('');

  useEffect(() => {
    loadData();
    const interval = setInterval(() => {
      loadNotifications();
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadData = async () => {
    try {
      const [accountsData, transactionsData, notificationsData, unreadData] = await Promise.all([
        api.accounts.list(),
        api.transactions.list(),
        api.notifications.list(),
        api.notifications.unreadCount(),
      ]);
      setAccounts(accountsData);
      setTransactions(transactionsData);
      setNotifications(notificationsData);
      setUnreadCount(unreadData.count);
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadNotifications = async () => {
    try {
      const [notificationsData, unreadData] = await Promise.all([
        api.notifications.list(),
        api.notifications.unreadCount(),
      ]);
      setNotifications(notificationsData);
      setUnreadCount(unreadData.count);
    } catch (error) {
      console.error('Failed to load notifications:', error);
    }
  };

  const handleWithdraw = async (e) => {
  e.preventDefault();
  setWithdrawLoading(true);
  setWithdrawMessage('');

  try {
    await api.transactions.withdraw(
      withdrawAccount, 
      parseFloat(withdrawAmount),
      'INR',
      withdrawDescription
    );
    setWithdrawMessage('Withdrawal successful!');
    setWithdrawAccount('');
    setWithdrawAmount('');
    setWithdrawDescription('');
    setTimeout(() => loadData(), 1000);
  } catch (error) {
    setWithdrawMessage(error.message);
  } finally {
    setWithdrawLoading(false);
  }
};


  const handleDeposit = async (e) => {
    e.preventDefault();
    setDepositLoading(true);
    setDepositMessage('');

    try {
      await api.transactions.deposit(
        depositAccount, 
        parseFloat(depositAmount),
        'INR',
        depositDescription
      );
      setDepositMessage('Deposit successful!');
      setDepositAccount('');
      setDepositAmount('');
      setDepositDescription('');
      setTimeout(() => loadData(), 1000);
    } catch (error) {
      setDepositMessage(error.message);
    } finally {
      setDepositLoading(false);
    }
  };


  const handleTransfer = async (e) => {
    e.preventDefault();
    setTransferLoading(true);
    setTransferMessage('');

    try {
      await api.transactions.transfer(fromAccount, toAccount, parseFloat(amount));
      setTransferMessage('Transfer successful!');
      setFromAccount('');
      setToAccount('');
      setAmount('');
      setTimeout(() => loadData(), 1000);
    } catch (error) {
      setTransferMessage(error.message);
    } finally {
      setTransferLoading(false);
    }
  };

  const totalBalance = accounts.reduce((sum, acc) => sum + acc.balance, 0);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <div className={`fixed lg:static inset-y-0 left-0 z-50 transform ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      } lg:translate-x-0 transition-transform duration-300`}>
        <div className="w-64 bg-white border-r border-gray-200 flex flex-col h-screen">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">SecureBank</h1>
                <p className="text-xs text-gray-500 capitalize">{user.role}</p>
              </div>
            </div>
          </div>

          <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
            {[
              { id: 'overview', icon: TrendingUp, label: 'Overview' },
              { id: 'accounts', icon: CreditCard, label: 'Accounts' },
              { id: 'deposit', icon: ArrowDownCircle, label: 'Deposit' },
              { id: 'withdraw', icon: ArrowUpCircle, label: 'Withdraw' },
              { id: 'transfer', icon: Send, label: 'Transfer' },
              { id: 'transactions', icon: History, label: 'Transactions' },
              { id: 'notifications', icon: Bell, label: 'Notifications', badge: unreadCount },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setSidebarOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                  activeTab === item.id
                    ? 'bg-blue-50 text-blue-600'
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
                {item.badge > 0 && (
                  <span className="ml-auto bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                    {item.badge}
                  </span>
                )}
              </button>
            ))}
          </nav>

          <div className="p-4 border-t border-gray-200">
            <div className="flex items-center gap-3 px-4 py-3 bg-gray-50 rounded-lg mb-2">
              <User className="w-5 h-5 text-gray-600" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">{user.email}</p>
              </div>
            </div>
            <button
              onClick={onLogout}
              className="w-full flex items-center gap-3 px-4 py-3 text-red-600 hover:bg-red-50 rounded-lg transition-all"
            >
              <LogOut className="w-5 h-5" />
              <span className="font-medium">Logout</span>
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 hover:bg-gray-100 rounded-lg"
            >
              {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            <h2 className="text-xl font-bold text-gray-900 capitalize">{activeTab}</h2>
            <div className="flex items-center gap-4">
              <div className="relative">
                <Bell className="w-6 h-6 text-gray-600" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs flex items-center justify-center rounded-full">
                    {unreadCount}
                  </span>
                )}
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 p-6 overflow-auto">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <button
                  onClick={() => setActiveTab('accounts')}
                  className="group relative bg-gradient-to-br from-blue-500 via-blue-600 to-purple-600 rounded-3xl p-8 text-white text-left hover:shadow-2xl transition-all transform hover:scale-105 cursor-pointer overflow-hidden"
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl group-hover:w-40 group-hover:h-40 transition-all"></div>
                  <div className="relative z-10">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-sm">
                        <CreditCard className="w-7 h-7" />
                      </div>
                      <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center group-hover:rotate-45 transition-transform">
                        <TrendingUp className="w-5 h-5" />
                      </div>
                    </div>
                    <p className="text-blue-100 text-sm mb-2 font-medium">Total Balance</p>
                    <h3 className="text-5xl font-bold mb-2">₹{totalBalance.toLocaleString()}</h3>
                    <div className="flex items-center justify-between mt-6">
                      <p className="text-blue-100 text-sm">{accounts.length} Active Accounts</p>
                      <span className="text-xs text-white/80 group-hover:text-white transition-colors">View Details →</span>
                    </div>
                  </div>
                </button>

                <button
                  onClick={() => setActiveTab('transactions')}
                  className="group relative bg-white rounded-3xl p-8 border-2 border-gray-100 text-left hover:shadow-2xl hover:border-green-200 transition-all transform hover:scale-105 cursor-pointer overflow-hidden"
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-green-400/20 to-emerald-400/20 rounded-full blur-2xl group-hover:w-40 group-hover:h-40 transition-all"></div>
                  <div className="relative z-10">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-14 h-14 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center shadow-lg">
                        <History className="w-7 h-7 text-white" />
                      </div>
                      <div className="w-10 h-10 bg-green-50 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                        <TrendingUp className="w-5 h-5 text-green-600" />
                      </div>
                    </div>
                    <p className="text-gray-600 text-sm mb-2 font-medium">Total Transactions</p>
                    <h3 className="text-5xl font-bold text-gray-900 mb-2">{transactions.length}</h3>
                    <div className="flex items-center justify-between mt-6">
                      <p className="text-green-600 text-sm font-semibold flex items-center gap-1">
                        <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                        Active
                      </p>
                      <span className="text-xs text-gray-400 group-hover:text-green-600 transition-colors">View All →</span>
                    </div>
                  </div>
                </button>

                <button
                  onClick={() => setActiveTab('notifications')}
                  className="group relative bg-gradient-to-br from-orange-500 to-pink-500 rounded-3xl p-8 text-white text-left hover:shadow-2xl transition-all transform hover:scale-105 cursor-pointer overflow-hidden"
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl group-hover:w-40 group-hover:h-40 transition-all"></div>
                  <div className="relative z-10">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-sm relative">
                        <Bell className="w-7 h-7" />
                        {unreadCount > 0 && (
                          <span className="absolute -top-1 -right-1 w-6 h-6 bg-white text-orange-600 text-xs font-bold rounded-full flex items-center justify-center animate-bounce">
                            {unreadCount}
                          </span>
                        )}
                      </div>
                    </div>
                    <p className="text-orange-100 text-sm mb-2 font-medium">Notifications</p>
                    <h3 className="text-5xl font-bold mb-2">{unreadCount}</h3>
                    <div className="flex items-center justify-between mt-6">
                      <p className="text-orange-100 text-sm">Unread messages</p>
                      <span className="text-xs text-white/80 group-hover:text-white transition-colors">Check Now →</span>
                    </div>
                  </div>
                </button>
              </div>

              <div className="bg-white rounded-2xl p-6 border border-gray-200">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Recent Transactions</h3>
                <div className="space-y-3">
                  {transactions.slice(0, 5).map((tx) => (
                    <div key={tx.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          accounts.find(a => a.accountNumber === tx.fromAccount) ? 'bg-red-100' : 'bg-green-100'
                        }`}>
                          <Send className={`w-5 h-5 ${
                            accounts.find(a => a.accountNumber === tx.fromAccount) ? 'text-red-600' : 'text-green-600'
                          }`} />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{tx.txId}</p>
                          <p className="text-sm text-gray-600">
                            {tx.fromAccount} → {tx.toAccount}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`font-bold ${
                          accounts.find(a => a.accountNumber === tx.fromAccount) ? 'text-red-600' : 'text-green-600'
                        }`}>
                          {accounts.find(a => a.accountNumber === tx.fromAccount) ? '-' : '+'}₹{tx.amount.toLocaleString()}
                        </p>
                        <p className="text-sm text-gray-600">{tx.status}</p>
                      </div>
                    </div>
                  ))}
                  {transactions.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      <p>No transactions yet</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'accounts' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-bold text-gray-900">Your Accounts</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {accounts.map((account) => (
                  <div key={account.id} className="bg-gradient-to-br from-gray-900 to-gray-700 rounded-2xl p-6 text-white relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-white opacity-5 rounded-full -mr-16 -mt-16"></div>
                    <div className="relative">
                      <p className="text-gray-400 text-sm mb-2">Account Number</p>
                      <h4 className="text-xl font-mono font-bold mb-6">{account.accountNumber}</h4>
                      <div className="flex items-end justify-between">
                        <div>
                          <p className="text-gray-400 text-sm mb-1">Balance</p>
                          <h3 className="text-3xl font-bold">₹{account.balance.toLocaleString()}</h3>
                        </div>
                        <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                          account.status === 'active' ? 'bg-green-500' : 'bg-red-500'
                        }`}>
                          {account.status.toUpperCase()}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                {accounts.length === 0 && (
                  <div className="col-span-2 text-center py-12 text-gray-500">
                    <CreditCard className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p>No accounts found. Contact admin to create an account.</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'deposit' && (
  <div className="max-w-2xl">
    <div className="bg-white rounded-2xl p-8 border border-gray-200">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
          <ArrowDownCircle className="w-6 h-6 text-white" />
        </div>
        <div>
          <h3 className="text-2xl font-bold text-gray-900">Deposit Money</h3>
          <p className="text-sm text-gray-600">Add funds to your account</p>
        </div>
      </div>

      <form onSubmit={handleDeposit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Select Account
          </label>
          <select
            value={depositAccount}
            onChange={(e) => setDepositAccount(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            required
          >
            <option value="">Choose account...</option>
            {accounts.filter(acc => acc.status === 'active').map((acc) => (
              <option key={acc.id} value={acc.accountNumber}>
                {acc.accountNumber} (₹{acc.balance.toLocaleString()})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Amount
          </label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">₹</span>
            <input
              type="number"
              value={depositAmount}
              onChange={(e) => setDepositAmount(e.target.value)}
              className="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              placeholder="0.00"
              step="0.01"
              min="0.01"
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Description (Optional)
          </label>
          <input
            type="text"
            value={depositDescription}
            onChange={(e) => setDepositDescription(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            placeholder="e.g., Monthly salary, Freelance payment"
            maxLength={100}
          />
        </div>

        {depositMessage && (
          <div className={`flex items-center gap-2 p-4 rounded-lg ${
            depositMessage.includes('successful') 
              ? 'bg-green-50 border border-green-200' 
              : 'bg-red-50 border border-red-200'
          }`}>
            <AlertCircle className={`w-5 h-5 ${
              depositMessage.includes('successful') ? 'text-green-600' : 'text-red-600'
            }`} />
            <p className={`text-sm ${
              depositMessage.includes('successful') ? 'text-green-800' : 'text-red-800'
            }`}>
              {depositMessage}
            </p>
          </div>
        )}

        <button
          type="submit"
          disabled={depositLoading || accounts.length === 0}
          className="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white py-3 rounded-lg font-semibold hover:from-green-600 hover:to-emerald-700 transition-all disabled:opacity-50"
        >
          {depositLoading ? 'Processing...' : 'Deposit Money'}
        </button>
      </form>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
        <h4 className="font-semibold text-blue-900 mb-2 flex items-center gap-2">
          <AlertCircle className="w-4 h-4" />
          Important Information
        </h4>
        <ul className="text-sm text-blue-800 space-y-1">
          <li>• Deposits are processed instantly</li>
          <li>• You'll receive a notification after successful deposit</li>
          <li>• Minimum deposit amount: ₹0.01</li>
        </ul>
      </div>
    </div>
  </div>
)}

{activeTab === 'withdraw' && (
  <div className="max-w-2xl">
    <div className="bg-white rounded-2xl p-8 border border-gray-200">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-orange-600 rounded-xl flex items-center justify-center">
          <ArrowUpCircle className="w-6 h-6 text-white" />
        </div>
        <div>
          <h3 className="text-2xl font-bold text-gray-900">Withdraw Money</h3>
          <p className="text-sm text-gray-600">Withdraw funds from your account</p>
        </div>
      </div>

      <form onSubmit={handleWithdraw} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Select Account
          </label>
          <select
            value={withdrawAccount}
            onChange={(e) => setWithdrawAccount(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
            required
          >
            <option value="">Choose account...</option>
            {accounts.filter(acc => acc.status === 'active' && acc.balance > 0).map((acc) => (
              <option key={acc.id} value={acc.accountNumber}>
                {acc.accountNumber} (₹{acc.balance.toLocaleString()})
              </option>
            ))}
          </select>
        </div>

        {/* Show current balance */}
        {withdrawAccount && (
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Available Balance</span>
              <span className="text-2xl font-bold text-blue-600">
                ₹{accounts.find(a => a.accountNumber === withdrawAccount)?.balance.toLocaleString()}
              </span>
            </div>
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Amount to Withdraw
          </label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">₹</span>
            <input
              type="number"
              value={withdrawAmount}
              onChange={(e) => setWithdrawAmount(e.target.value)}
              className="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              placeholder="0.00"
              step="0.01"
              min="0.01"
              max={withdrawAccount ? accounts.find(a => a.accountNumber === withdrawAccount)?.balance : undefined}
              required
            />
          </div>
          {withdrawAmount && withdrawAccount && (
            <p className="text-xs text-gray-600 mt-2">
              Remaining balance: <span className="font-semibold text-gray-800">
                ₹{(accounts.find(a => a.accountNumber === withdrawAccount)?.balance - parseFloat(withdrawAmount || 0)).toLocaleString()}
              </span>
            </p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Purpose / Description (Optional)
          </label>
          <input
            type="text"
            value={withdrawDescription}
            onChange={(e) => setWithdrawDescription(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
            placeholder="e.g., ATM withdrawal, Cash needed, Bill payment"
            maxLength={100}
          />
        </div>

        {withdrawMessage && (
          <div className={`flex items-center gap-2 p-4 rounded-lg ${
            withdrawMessage.includes('successful') 
              ? 'bg-green-50 border border-green-200' 
              : 'bg-red-50 border border-red-200'
          }`}>
            <AlertCircle className={`w-5 h-5 ${
              withdrawMessage.includes('successful') ? 'text-green-600' : 'text-red-600'
            }`} />
            <p className={`text-sm ${
              withdrawMessage.includes('successful') ? 'text-green-800' : 'text-red-800'
            }`}>
              {withdrawMessage}
            </p>
          </div>
        )}

        <button
          type="submit"
          disabled={withdrawLoading || accounts.length === 0 || !withdrawAccount}
          className="w-full bg-gradient-to-r from-red-500 to-orange-600 text-white py-3 rounded-lg font-semibold hover:from-red-600 hover:to-orange-700 transition-all disabled:opacity-50"
        >
          {withdrawLoading ? (
            <span className="flex items-center justify-center gap-2">
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              Processing...
            </span>
          ) : (
            'Withdraw Money'
          )}
        </button>
      </form>

      <div className="mt-6 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
        <h4 className="font-semibold text-yellow-800 mb-2 flex items-center gap-2">
          <AlertCircle className="w-4 h-4" />
          Withdrawal Guidelines
        </h4>
        <ul className="text-sm text-yellow-700 space-y-1">
          <li>• Withdrawals are processed instantly</li>
          <li>• You can only withdraw from accounts with sufficient balance</li>
          <li>• You'll receive a notification after successful withdrawal</li>
          <li>• All withdrawals are logged for security</li>
        </ul>
      </div>
    </div>
  </div>
)}
          {activeTab === 'transfer' && (
            <div className="max-w-2xl">
              <div className="bg-white rounded-2xl p-8 border border-gray-200">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Transfer Money</h3>

                <form onSubmit={handleTransfer} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">From Account</label>
                    <select
                      value={fromAccount}
                      onChange={(e) => setFromAccount(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    >
                      <option value="">Select account</option>
                      {accounts.map((acc) => (
                        <option key={acc.id} value={acc.accountNumber}>
                          {acc.accountNumber} (₹{acc.balance.toLocaleString()})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">To Account</label>
                    <input
                      type="text"
                      value={toAccount}
                      onChange={(e) => setToAccount(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Enter account number"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Amount</label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">₹</span>
                      <input
                        type="number"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        className="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="0.00"
                        step="0.01"
                        min="0.01"
                        required
                      />
                    </div>
                  </div>

                  {transferMessage && (
                    <div className={`flex items-center gap-2 p-4 rounded-lg ${
                      transferMessage.includes('successful') ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
                    }`}>
                      <AlertCircle className={`w-5 h-5 ${
                        transferMessage.includes('successful') ? 'text-green-600' : 'text-red-600'
                      }`} />
                      <p className={`text-sm ${
                        transferMessage.includes('successful') ? 'text-green-800' : 'text-red-800'
                      }`}>
                        {transferMessage}
                      </p>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={transferLoading}
                    className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 rounded-lg font-semibold hover:from-blue-600 hover:to-purple-700 transition-all disabled:opacity-50"
                  >
                    {transferLoading ? 'Processing...' : 'Transfer Money'}
                  </button>
                </form>
              </div>
            </div>
          )}

          {activeTab === 'transactions' && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-gray-900">Transaction History</h3>

              <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b border-gray-200">
                      <tr>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Transaction ID</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">From</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">To</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Amount</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Status</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Date</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {transactions.map((tx) => (
                        <tr key={tx.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 text-sm font-mono text-gray-900">{tx.txId}</td>
                          <td className="px-6 py-4 text-sm text-gray-600">{tx.fromAccount}</td>
                          <td className="px-6 py-4 text-sm text-gray-600">{tx.toAccount}</td>
                          <td className="px-6 py-4 text-sm font-semibold text-gray-900">
                            ₹{tx.amount.toLocaleString()}
                          </td>
                          <td className="px-6 py-4">
                            <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                              tx.status === 'SUCCESS' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                            }`}>
                              {tx.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-600">
                            {new Date(tx.createdAt).toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {transactions.length === 0 && (
                    <div className="text-center py-12 text-gray-500">
                      <History className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>No transactions yet</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'notifications' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-bold text-gray-900">Notifications</h3>
                
              </div>

              <div className="space-y-3">
                {notifications.map((notif) => (
                  <div
                    key={notif.id}
                    className={`p-4 rounded-lg border transition-all ${
                      notif.delivered ? 'bg-white border-gray-200' : 'bg-blue-50 border-blue-200'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                        notif.type === 'TRANSACTION_SENT' ? 'bg-red-100' : 'bg-green-100'
                      }`}>
                        <Send className={`w-5 h-5 ${
                          notif.type === 'TRANSACTION_SENT' ? 'text-red-600' : 'text-green-600'
                        }`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-gray-900">{notif.type.replace(/_/g, ' ')}</p>
                        <p className="text-sm text-gray-600 mt-1">{notif.payload.message}</p>
                        <p className="text-xs text-gray-500 mt-2">
                          {new Date(notif.createdAt).toLocaleString()}
                        </p>
                      </div>
                     
                    </div>
                  </div>
                ))}

                {notifications.length === 0 && (
                  <div className="text-center py-12 text-gray-500">
                    <Bell className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p>No notifications yet</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

// Admin Dashboard Component
const AdminDashboard = ({ user, onLogout }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [stats, setStats] = useState({ users: 0, accounts: 0, transactions: 0 });
  const [allAccounts, setAllAccounts] = useState([]);
  const [allTransactions, setAllTransactions] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Create account form
  const [newAccountNumber, setNewAccountNumber] = useState('');
  const [selectedUserId, setSelectedUserId] = useState('');
  const [newBalance, setNewBalance] = useState('1000');
  const [createMessage, setCreateMessage] = useState('');

  // Freeze account
  const [freezeAccountNumber, setFreezeAccountNumber] = useState('');
  const [freezeMessage, setFreezeMessage] = useState('');

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDepositAccount, setSelectedDepositAccount] = useState('');
  const [adminDepositAmount, setAdminDepositAmount] = useState('');
  const [adminDepositDescription, setAdminDepositDescription] = useState('');
  const [adminDepositLoading, setAdminDepositLoading] = useState(false);
  const [adminDepositMessage, setAdminDepositMessage] = useState('');

  const [withdrawSearchTerm, setWithdrawSearchTerm] = useState('');
const [selectedWithdrawAccount, setSelectedWithdrawAccount] = useState('');
const [adminWithdrawAmount, setAdminWithdrawAmount] = useState('');
const [adminWithdrawDescription, setAdminWithdrawDescription] = useState('');
const [adminWithdrawLoading, setAdminWithdrawLoading] = useState(false);
const [adminWithdrawMessage, setAdminWithdrawMessage] = useState('');

// ADD HANDLER FUNCTION:
const handleAdminWithdraw = async (e) => {
  e.preventDefault();
  setAdminWithdrawLoading(true);
  setAdminWithdrawMessage('');

  try {
    await api.transactions.withdraw(
      selectedWithdrawAccount,
      parseFloat(adminWithdrawAmount),
      'INR',
      adminWithdrawDescription || 'Admin withdrawal'
    );
    setAdminWithdrawMessage(`Successfully withdrew ₹${adminWithdrawAmount} from account ${selectedWithdrawAccount}!`);
    setSelectedWithdrawAccount('');
    setAdminWithdrawAmount('');
    setAdminWithdrawDescription('');
    setWithdrawSearchTerm('');
    loadAdminData();
  } catch (error) {
    setAdminWithdrawMessage(error.message);
  } finally {
    setAdminWithdrawLoading(false);
  }
};

// FILTER ACCOUNTS:
const filteredWithdrawAccounts = withdrawSearchTerm
  ? allAccounts.filter(acc =>
      acc.accountNumber.toLowerCase().includes(withdrawSearchTerm.toLowerCase()) ||
      acc.accountType.toLowerCase().includes(withdrawSearchTerm.toLowerCase()) ||
      (acc.userId && acc.userId.toLowerCase().includes(withdrawSearchTerm.toLowerCase()))
    )
  : allAccounts;

const selectedWithdrawAccountData = allAccounts.find(acc => acc.accountNumber === selectedWithdrawAccount);

  useEffect(() => {
    loadAdminData();
  }, []);

  const loadAdminData = async () => {
  try {
    const [statsData, accountsData, transactionsData] = await Promise.all([
      api.admin.stats(),
      api.accounts.list(),
      api.transactions.list(),
    ]);
    setStats(statsData);
    setAllAccounts(accountsData);
    setAllTransactions(transactionsData);
    
    // Fetch users through API Gateway
    try {
      const usersData = await api.users.listUsersOnly();
      console.log('Users loaded:', usersData);
      setAllUsers(usersData);
    } catch (err) {
      console.error('Error fetching users:', err);
      // Fallback: extract from accounts
      const uniqueUserIds = [...new Set(accountsData.map(acc => acc.userId))];
      setAllUsers(uniqueUserIds.map(id => ({ id, email: `User ${id.slice(0, 8)}...` })));
    }
  } catch (error) {
    console.error('Failed to load admin data:', error);
  } finally {
    setLoading(false);
  }
};

  const handleCreateAccount = async (e) => {
    e.preventDefault();
    setCreateMessage('');
    
    if (!selectedUserId) {
      setCreateMessage('Please select a user');
      return;
    }
    
    try {
      await api.accounts.create(newAccountNumber, selectedUserId, parseFloat(newBalance));
      setCreateMessage('Account created successfully!');
      setNewAccountNumber('');
      setSelectedUserId('');
      setNewBalance('1000');
      loadAdminData();
    } catch (error) {
      setCreateMessage(error.message);
    }
  };

  const handleAdminDeposit = async (e) => {
  e.preventDefault();
  setAdminDepositLoading(true);
  setAdminDepositMessage('');

  try {
    await api.transactions.deposit(
      selectedDepositAccount,
      parseFloat(adminDepositAmount),
      'INR',
      adminDepositDescription || 'Admin deposit'
    );
    setAdminDepositMessage(`Successfully deposited ₹${adminDepositAmount} to account ${selectedDepositAccount}!`);
    setSelectedDepositAccount('');
    setAdminDepositAmount('');
    setAdminDepositDescription('');
    setSearchTerm('');
    loadAdminData();
  } catch (error) {
    setAdminDepositMessage(error.message);
  } finally {
    setAdminDepositLoading(false);
  }
};

// Filter accounts based on search:
const filteredAccounts = searchTerm
  ? allAccounts.filter(acc =>
      acc.accountNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      acc.accountType.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (acc.userId && acc.userId.toLowerCase().includes(searchTerm.toLowerCase()))
    )
  : allAccounts;

const selectedAccountData = allAccounts.find(acc => acc.accountNumber === selectedDepositAccount);


  const handleFreezeAccount = async (accountNumber, freeze) => {
    setFreezeMessage('');
    try {
      await api.admin.freezeAccount(accountNumber, freeze);
      setFreezeMessage(`Account ${freeze ? 'frozen' : 'unfrozen'} successfully!`);
      loadAdminData();
    } catch (error) {
      setFreezeMessage(error.message);
    }
  };

  const handleDeleteAccount = async (accountId) => {
    if (window.confirm('Are you sure you want to delete this account?')) {
      try {
        await api.accounts.delete(accountId);
        loadAdminData();
      } catch (error) {
        alert(error.message);
      }
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <div className={`fixed lg:static inset-y-0 left-0 z-50 transform ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      } lg:translate-x-0 transition-transform duration-300`}>
        <div className="w-64 bg-white border-r border-gray-200 flex flex-col h-screen">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-full flex items-center justify-center">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Admin Panel</h1>
                <p className="text-xs text-purple-600 font-semibold">Administrator</p>
              </div>
            </div>
          </div>

          <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
            {[
              { id: 'overview', icon: TrendingUp, label: 'Overview' },
              { id: 'users', icon: Users, label: 'All Accounts' },
              { id: 'create', icon: Plus, label: 'Create Account' },
              { id: 'deposit', icon: ArrowDownCircle, label: 'Deposit Money' },
              { id: 'withdraw', icon: ArrowUpCircle, label: 'Withdraw Money' },
              { id: 'transactions', icon: History, label: 'All Transactions' },
              { id: 'manage', icon: Settings, label: 'Manage Accounts' },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setSidebarOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                  activeTab === item.id
                    ? 'bg-purple-50 text-purple-600'
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </button>
            ))}
          </nav>

          <div className="p-4 border-t border-gray-200">
            <div className="flex items-center gap-3 px-4 py-3 bg-purple-50 rounded-lg mb-2">
              <User className="w-5 h-5 text-purple-600" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">{user.email}</p>
              </div>
            </div>
            <button
              onClick={onLogout}
              className="w-full flex items-center gap-3 px-4 py-3 text-red-600 hover:bg-red-50 rounded-lg transition-all"
            >
              <LogOut className="w-5 h-5" />
              <span className="font-medium">Logout</span>
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 hover:bg-gray-100 rounded-lg"
            >
              {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            <h2 className="text-xl font-bold text-gray-900 capitalize">{activeTab}</h2>
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-purple-600" />
              <span className="text-sm font-medium text-purple-600">Admin</span>
            </div>
          </div>
        </header>

        <main className="flex-1 p-6 overflow-auto">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <button
                  onClick={() => setActiveTab('users')}
                  className="group relative bg-gradient-to-br from-purple-500 via-purple-600 to-pink-600 rounded-3xl p-8 text-white text-left hover:shadow-2xl transition-all transform hover:scale-105 cursor-pointer overflow-hidden"
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl group-hover:w-40 group-hover:h-40 transition-all"></div>
                  <div className="relative z-10">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-sm">
                        <Users className="w-8 h-8" />
                      </div>
                      <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center group-hover:rotate-12 transition-transform">
                        <Shield className="w-5 h-5" />
                      </div>
                    </div>
                    <p className="text-purple-100 text-sm mb-2 font-medium">Total Users</p>
                    <h3 className="text-5xl font-bold mb-2">{stats.users}</h3>
                    <div className="flex items-center justify-between mt-6">
                      <p className="text-purple-100 text-sm">Registered users</p>
                      <span className="text-xs text-white/80 group-hover:text-white transition-colors">View All →</span>
                    </div>
                  </div>
                </button>

                <button
                  onClick={() => setActiveTab('users')}
                  className="group relative bg-gradient-to-br from-blue-500 via-cyan-500 to-teal-500 rounded-3xl p-8 text-white text-left hover:shadow-2xl transition-all transform hover:scale-105 cursor-pointer overflow-hidden"
                >
                  <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/10 rounded-full blur-2xl group-hover:w-40 group-hover:h-40 transition-all"></div>
                  <div className="relative z-10">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-sm">
                        <CreditCard className="w-8 h-8" />
                      </div>
                      <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                        <TrendingUp className="w-5 h-5" />
                      </div>
                    </div>
                    <p className="text-cyan-100 text-sm mb-2 font-medium">Total Accounts</p>
                    <h3 className="text-5xl font-bold mb-2">{stats.accounts}</h3>
                    <div className="flex items-center justify-between mt-6">
                      <p className="text-cyan-100 text-sm">Bank accounts</p>
                      <span className="text-xs text-white/80 group-hover:text-white transition-colors">View All →</span>
                    </div>
                  </div>
                </button>

                <button
                  onClick={() => setActiveTab('transactions')}
                  className="group relative bg-gradient-to-br from-emerald-500 via-green-500 to-teal-500 rounded-3xl p-8 text-white text-left hover:shadow-2xl transition-all transform hover:scale-105 cursor-pointer overflow-hidden"
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl group-hover:w-40 group-hover:h-40 transition-all"></div>
                  <div className="relative z-10">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-sm">
                        <History className="w-8 h-8" />
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="w-2 h-2 bg-white rounded-full animate-pulse"></span>
                        <span className="w-2 h-2 bg-white rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></span>
                        <span className="w-2 h-2 bg-white rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></span>
                      </div>
                    </div>
                    <p className="text-emerald-100 text-sm mb-2 font-medium">Total Transactions</p>
                    <h3 className="text-5xl font-bold mb-2">{stats.transactions}</h3>
                    <div className="flex items-center justify-between mt-6">
                      <p className="text-emerald-100 text-sm">All transactions</p>
                      <span className="text-xs text-white/80 group-hover:text-white transition-colors">View All →</span>
                    </div>
                  </div>
                </button>
              </div>

              <div className="bg-white rounded-2xl p-6 border border-gray-200">
                <h3 className="text-lg font-bold text-gray-900 mb-4">System Overview</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-600 mb-1">Active Accounts</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {allAccounts.filter(a => a.status === 'active').length}
                    </p>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-600 mb-1">Frozen Accounts</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {allAccounts.filter(a => a.status === 'frozen').length}
                    </p>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-600 mb-1">Total Balance</p>
                    <p className="text-2xl font-bold text-gray-900">
                      ₹{allAccounts.reduce((sum, a) => sum + a.balance, 0).toLocaleString()}
                    </p>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-600 mb-1">Success Rate</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {allTransactions.length > 0 
                        ? Math.round((allTransactions.filter(t => t.status === 'SUCCESS').length / allTransactions.length) * 100)
                        : 0}%
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'users' && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-gray-900">All Accounts</h3>

              <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b border-gray-200">
                      <tr>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Account Number</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">User ID</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Balance</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Currency</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Status</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {allAccounts.map((account) => (
                        <tr key={account.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 text-sm font-mono text-gray-900">{account.accountNumber}</td>
                          <td className="px-6 py-4 text-sm text-gray-600">{account.userId}</td>
                          <td className="px-6 py-4 text-sm font-semibold text-gray-900">
                            ₹{account.balance.toLocaleString()}
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-600">{account.currency}</td>
                          <td className="px-6 py-4">
                            <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                              account.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                            }`}>
                              {account.status.toUpperCase()}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <button
                              onClick={() => handleDeleteAccount(account.id)}
                              className="text-red-600 hover:text-red-800"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {allAccounts.length === 0 && (
                    <div className="text-center py-12 text-gray-500">
                      <Users className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>No accounts found</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'create' && (
            <div className="max-w-2xl">
              <div className="bg-white rounded-2xl p-8 border border-gray-200">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Create New Account</h3>

                <form onSubmit={handleCreateAccount} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Select User</label>
                    <select
                      value={selectedUserId}
                      onChange={(e) => setSelectedUserId(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      required
                    >
                      <option value="">Choose a user...</option>
                      {allUsers.map((u) => (
                        <option key={u.id} value={u.id}>
                          {u.email} (ID: {u.id})
                        </option>
                      ))}
                    </select>
                    <p className="text-xs text-gray-500 mt-2">
                      Note: Users are identified by their registered accounts. New users need to register first.
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Account Number</label>
                    <input
                      type="text"
                      value={newAccountNumber}
                      onChange={(e) => setNewAccountNumber(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      placeholder="e.g., ACC1001"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Initial Balance</label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">₹</span>
                      <input
                        type="number"
                        value={newBalance}
                        onChange={(e) => setNewBalance(e.target.value)}
                        className="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        placeholder="1000"
                        step="0.01"
                        min="0"
                        required
                      />
                    </div>
                  </div>

                  {createMessage && (
                    <div className={`flex items-center gap-2 p-4 rounded-lg ${
                      createMessage.includes('success') ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
                    }`}>
                      <AlertCircle className={`w-5 h-5 ${
                        createMessage.includes('success') ? 'text-green-600' : 'text-red-600'
                      }`} />
                      <p className={`text-sm ${
                        createMessage.includes('success') ? 'text-green-800' : 'text-red-800'
                      }`}>
                        {createMessage}
                      </p>
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full bg-gradient-to-r from-purple-500 to-pink-600 text-white py-3 rounded-lg font-semibold hover:from-purple-600 hover:to-pink-700 transition-all"
                  >
                    Create Account
                  </button>
                </form>

                <div className="mt-8 p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <h4 className="font-semibold text-blue-900 mb-2">Quick Guide:</h4>
                  <ol className="text-sm text-blue-800 space-y-1 list-decimal list-inside">
                    <li>Users must register first in the login page</li>
                    <li>After registration, their User ID appears here</li>
                    <li>Select user from dropdown</li>
                    <li>Assign unique account number (e.g., ACC1001)</li>
                    <li>Set initial balance</li>
                  </ol>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'deposit' && (
  <div className="max-w-3xl">
    <div className="bg-white rounded-2xl p-8 border border-gray-200">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center">
          <ArrowDownCircle className="w-6 h-6 text-white" />
        </div>
        <div>
          <h3 className="text-2xl font-bold text-gray-900">Admin: Deposit Money</h3>
          <p className="text-sm text-gray-600">Deposit funds to any user account</p>
        </div>
      </div>

      {adminDepositMessage && (
        <div className={`flex items-center gap-2 p-4 rounded-lg mb-6 ${
          adminDepositMessage.includes('Success') 
            ? 'bg-green-50 border border-green-200' 
            : 'bg-red-50 border border-red-200'
        }`}>
          <AlertCircle className={`w-5 h-5 ${
            adminDepositMessage.includes('Success') ? 'text-green-600' : 'text-red-600'
          }`} />
          <p className={`text-sm ${
            adminDepositMessage.includes('Success') ? 'text-green-800' : 'text-red-800'
          }`}>
            {adminDepositMessage}
          </p>
        </div>
      )}

      <form onSubmit={handleAdminDeposit} className="space-y-6">
        {/* Search Box */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Search Account
          </label>
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by account number, user ID, or type..."
              className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            />
          </div>
          <p className="text-xs text-gray-500 mt-1">
            Showing {filteredAccounts.length} of {allAccounts.length} accounts
          </p>
        </div>

        {/* Account Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Select Account
          </label>
          <select
            value={selectedDepositAccount}
            onChange={(e) => setSelectedDepositAccount(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            required
          >
            <option value="">-- Select an account --</option>
            {filteredAccounts.map(acc => (
              <option key={acc.id} value={acc.accountNumber}>
                {acc.accountNumber} | {acc.accountType} | User: {acc.userId.slice(0, 8)}... | ₹{acc.balance.toLocaleString()}
              </option>
            ))}
          </select>
        </div>

        {/* Selected Account Details */}
        {selectedAccountData && (
          <div className="p-5 bg-purple-50 rounded-lg border border-purple-200">
            <div className="flex items-center gap-2 mb-3">
              <User className="w-5 h-5 text-purple-600" />
              <h4 className="font-semibold text-gray-800">Account Details</h4>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-600">Account:</span>
                <p className="font-semibold text-gray-800">{selectedAccountData.accountNumber}</p>
              </div>
              <div>
                <span className="text-gray-600">Type:</span>
                <p className="font-semibold text-gray-800">{selectedAccountData.accountType}</p>
              </div>
              <div>
                <span className="text-gray-600">User ID:</span>
                <p className="font-semibold text-gray-800 truncate">{selectedAccountData.userId}</p>
              </div>
              <div>
                <span className="text-gray-600">Current Balance:</span>
                <p className="font-semibold text-purple-600 text-lg">₹{selectedAccountData.balance.toLocaleString()}</p>
              </div>
            </div>
          </div>
        )}

        {/* Amount Input */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Deposit Amount
          </label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">₹</span>
            <input
              type="number"
              value={adminDepositAmount}
              onChange={(e) => setAdminDepositAmount(e.target.value)}
              className="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-lg font-semibold"
              placeholder="0.00"
              step="0.01"
              min="0.01"
              required
              disabled={!selectedDepositAccount}
            />
          </div>
          {adminDepositAmount && selectedAccountData && (
            <p className="text-xs text-gray-600 mt-2">
              New balance will be: <span className="font-semibold text-purple-600">
                ₹{(selectedAccountData.balance + parseFloat(adminDepositAmount)).toLocaleString()}
              </span>
            </p>
          )}
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Description / Reason
          </label>
          <input
            type="text"
            value={adminDepositDescription}
            onChange={(e) => setAdminDepositDescription(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            placeholder="e.g., Account correction, Promotional credit, Refund"
            maxLength={100}
            disabled={!selectedDepositAccount}
          />
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={adminDepositLoading || !selectedDepositAccount || !adminDepositAmount}
          className="w-full bg-gradient-to-r from-purple-500 to-pink-600 text-white py-4 rounded-lg font-semibold hover:from-purple-600 hover:to-pink-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {adminDepositLoading ? (
            <span className="flex items-center justify-center gap-2">
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              Processing Deposit...
            </span>
          ) : (
            'Deposit Money to Account'
          )}
        </button>
      </form>

      {/* Admin Warning */}
      <div className="mt-6 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
        <h4 className="font-semibold text-yellow-800 mb-2 flex items-center gap-2">
          <AlertCircle className="w-4 h-4" />
          Admin Privileges
        </h4>
        <ul className="text-sm text-yellow-700 space-y-1">
          <li>⚠️ You can deposit to ANY user's account as an administrator</li>
          <li>⚠️ All admin deposits are logged and auditable</li>
          <li>⚠️ Users will receive a notification for deposits</li>
          <li>⚠️ Please provide a clear description for audit trail</li>
        </ul>
      </div>
    </div>
  </div>
)}

{activeTab === 'withdraw' && (
  <div className="max-w-3xl">
    <div className="bg-white rounded-2xl p-8 border border-gray-200">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-orange-600 rounded-xl flex items-center justify-center">
          <ArrowUpCircle className="w-6 h-6 text-white" />
        </div>
        <div>
          <h3 className="text-2xl font-bold text-gray-900">Admin: Withdraw Money</h3>
          <p className="text-sm text-gray-600">Withdraw funds from any user account</p>
        </div>
      </div>

      {adminWithdrawMessage && (
        <div className={`flex items-center gap-2 p-4 rounded-lg mb-6 ${
          adminWithdrawMessage.includes('Success') 
            ? 'bg-green-50 border border-green-200' 
            : 'bg-red-50 border border-red-200'
        }`}>
          <AlertCircle className={`w-5 h-5 ${
            adminWithdrawMessage.includes('Success') ? 'text-green-600' : 'text-red-600'
          }`} />
          <p className={`text-sm ${
            adminWithdrawMessage.includes('Success') ? 'text-green-800' : 'text-red-800'
          }`}>
            {adminWithdrawMessage}
          </p>
        </div>
      )}

      <form onSubmit={handleAdminWithdraw} className="space-y-6">
        {/* Search Box */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Search Account
          </label>
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              value={withdrawSearchTerm}
              onChange={(e) => setWithdrawSearchTerm(e.target.value)}
              placeholder="Search by account number, user ID, or type..."
              className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
            />
          </div>
          <p className="text-xs text-gray-500 mt-1">
            Showing {filteredWithdrawAccounts.length} of {allAccounts.length} accounts
          </p>
        </div>

        {/* Account Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Select Account
          </label>
          <select
            value={selectedWithdrawAccount}
            onChange={(e) => setSelectedWithdrawAccount(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
            required
          >
            <option value="">-- Select an account --</option>
            {filteredWithdrawAccounts
              .filter(acc => acc.balance > 0)
              .map(acc => (
                <option key={acc.id} value={acc.accountNumber}>
                  {acc.accountNumber} | {acc.accountType} | User: {acc.userId.slice(0, 8)}... | ₹{acc.balance.toLocaleString()}
                </option>
              ))}
          </select>
          {filteredWithdrawAccounts.filter(acc => acc.balance > 0).length === 0 && (
            <p className="text-sm text-red-600 mt-2">
              No accounts with sufficient balance found
            </p>
          )}
        </div>

        {/* Selected Account Details */}
        {selectedWithdrawAccountData && (
          <div className="p-5 bg-red-50 rounded-lg border border-red-200">
            <div className="flex items-center gap-2 mb-3">
              <User className="w-5 h-5 text-red-600" />
              <h4 className="font-semibold text-gray-800">Account Details</h4>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-600">Account:</span>
                <p className="font-semibold text-gray-800">{selectedWithdrawAccountData.accountNumber}</p>
              </div>
              <div>
                <span className="text-gray-600">Type:</span>
                <p className="font-semibold text-gray-800">{selectedWithdrawAccountData.accountType}</p>
              </div>
              <div>
                <span className="text-gray-600">User ID:</span>
                <p className="font-semibold text-gray-800 truncate">{selectedWithdrawAccountData.userId}</p>
              </div>
              <div>
                <span className="text-gray-600">Current Balance:</span>
                <p className="font-semibold text-red-600 text-lg">₹{selectedWithdrawAccountData.balance.toLocaleString()}</p>
              </div>
            </div>
            {selectedWithdrawAccountData.balance === 0 && (
              <div className="mt-3 p-3 bg-red-100 rounded border border-red-300">
                <p className="text-sm text-red-800 font-medium">
                  ⚠️ This account has zero balance. Withdrawal not possible.
                </p>
              </div>
            )}
          </div>
        )}

        {/* Amount Input */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Withdrawal Amount
          </label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">₹</span>
            <input
              type="number"
              value={adminWithdrawAmount}
              onChange={(e) => setAdminWithdrawAmount(e.target.value)}
              className="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent text-lg font-semibold"
              placeholder="0.00"
              step="0.01"
              min="0.01"
              max={selectedWithdrawAccountData?.balance || undefined}
              required
              disabled={!selectedWithdrawAccount || selectedWithdrawAccountData?.balance === 0}
            />
          </div>
          {adminWithdrawAmount && selectedWithdrawAccountData && (
            <div className="mt-2">
              {parseFloat(adminWithdrawAmount) > selectedWithdrawAccountData.balance ? (
                <p className="text-xs text-red-600 font-semibold">
                  ⚠️ Insufficient funds! Maximum: ₹{selectedWithdrawAccountData.balance.toLocaleString()}
                </p>
              ) : (
                <p className="text-xs text-gray-600">
                  New balance will be: <span className="font-semibold text-red-600">
                    ₹{(selectedWithdrawAccountData.balance - parseFloat(adminWithdrawAmount)).toLocaleString()}
                  </span>
                </p>
              )}
            </div>
          )}
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Description / Reason
          </label>
          <input
            type="text"
            value={adminWithdrawDescription}
            onChange={(e) => setAdminWithdrawDescription(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
            placeholder="e.g., Account correction, Penalty, Chargeback"
            maxLength={100}
            disabled={!selectedWithdrawAccount}
          />
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={
            adminWithdrawLoading || 
            !selectedWithdrawAccount || 
            !adminWithdrawAmount || 
            (selectedWithdrawAccountData && parseFloat(adminWithdrawAmount) > selectedWithdrawAccountData.balance)
          }
          className="w-full bg-gradient-to-r from-red-500 to-orange-600 text-white py-4 rounded-lg font-semibold hover:from-red-600 hover:to-orange-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {adminWithdrawLoading ? (
            <span className="flex items-center justify-center gap-2">
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              Processing Withdrawal...
            </span>
          ) : (
            'Withdraw Money from Account'
          )}
        </button>
      </form>

      {/* Admin Warning */}
      <div className="mt-6 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
        <h4 className="font-semibold text-yellow-800 mb-2 flex items-center gap-2">
          <AlertCircle className="w-4 h-4" />
          Admin Privileges - Use with Caution
        </h4>
        <ul className="text-sm text-yellow-700 space-y-1">
          <li>⚠️ You can withdraw from ANY user's account as an administrator</li>
          <li>⚠️ All admin withdrawals are logged and auditable</li>
          <li>⚠️ Users will receive a notification for withdrawals</li>
          <li>⚠️ Cannot withdraw more than available balance</li>
          <li>⚠️ Please provide a clear description for audit trail</li>
        </ul>
      </div>
    </div>
  </div>
)}

          {activeTab === 'transactions' && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-gray-900">All Transactions</h3>

              <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b border-gray-200">
                      <tr>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Transaction ID</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">From</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">To</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Amount</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Status</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Date</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {allTransactions.map((tx) => (
                        <tr key={tx.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 text-sm font-mono text-gray-900">{tx.txId}</td>
                          <td className="px-6 py-4 text-sm text-gray-600">{tx.fromAccount}</td>
                          <td className="px-6 py-4 text-sm text-gray-600">{tx.toAccount}</td>
                          <td className="px-6 py-4 text-sm font-semibold text-gray-900">
                            ₹{tx.amount.toLocaleString()}
                          </td>
                          <td className="px-6 py-4">
                            <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                              tx.status === 'SUCCESS' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                            }`}>
                              {tx.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-600">
                            {new Date(tx.createdAt).toLocaleString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {allTransactions.length === 0 && (
                    <div className="text-center py-12 text-gray-500">
                      <History className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>No transactions yet</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'manage' && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-gray-900">Manage Accounts</h3>

              <div className="bg-white rounded-2xl p-8 border border-gray-200">
                <h4 className="text-lg font-bold text-gray-900 mb-4">Freeze/Unfreeze Account</h4>

                {freezeMessage && (
                  <div className={`flex items-center gap-2 p-4 rounded-lg mb-4 ${
                    freezeMessage.includes('success') ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
                  }`}>
                    <AlertCircle className={`w-5 h-5 ${
                      freezeMessage.includes('success') ? 'text-green-600' : 'text-red-600'
                    }`} />
                    <p className={`text-sm ${
                      freezeMessage.includes('success') ? 'text-green-800' : 'text-red-800'
                    }`}>
                      {freezeMessage}
                    </p>
                  </div>
                )}

                <div className="space-y-4">
                  {allAccounts.map((account) => (
                    <div key={account.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-mono font-semibold text-gray-900">{account.accountNumber}</p>
                        <p className="text-sm text-gray-600">Balance: ₹{account.balance.toLocaleString()}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                          account.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {account.status.toUpperCase()}
                        </span>
                        {account.status === 'active' ? (
                          <button
                            onClick={() => handleFreezeAccount(account.accountNumber, true)}
                            className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 text-sm font-medium"
                          >
                            Freeze
                          </button>
                        ) : (
                          <button
                            onClick={() => handleFreezeAccount(account.accountNumber, false)}
                            className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm font-medium"
                          >
                            Unfreeze
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

// Main App Component
const App = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      api.auth.me()
        .then((userData) => {
          setUser(userData);
          setIsAuthenticated(true);
        })
        .catch(() => {
          localStorage.removeItem('token');
        })
        .finally(() => {
          setLoading(false);
        });
    } else {
      setLoading(false);
    }
  }, []);

  const handleLogin = async () => {
    const userData = await api.auth.me();
    setUser(userData);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setUser(null);
    setIsAuthenticated(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return <LoginPage onLogin={handleLogin} />;
  }

  // Route to appropriate dashboard based on role
  if (user.role === 'admin') {
    return <AdminDashboard user={user} onLogout={handleLogout} />;
  }

  return <UserDashboard user={user} onLogout={handleLogout} />;
};

export default App;